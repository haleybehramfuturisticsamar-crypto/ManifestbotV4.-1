# Manifest V8.0 — Discord AI + Server Management Bot

Manifest V8.0 is a single-file `discord.py` bot with persistent SQLite memory, Groq AI, tickets, moderation, economy/XP, reaction roles, dead-chat revival, invite tracking, and a real voice/music engine.

## Maker identity

The configured Maker is **thunderxstorms5_** with Discord user ID:

`1386055253581103164`

The code uses the numeric Discord ID, not the username. You can still override it with `MAKER_USER_ID` in the environment.

## Install

1. Install Python 3.10+.
2. Install FFmpeg and make sure `ffmpeg` is on PATH, or set `FFMPEG_PATH`.
3. Install Python packages:

```bash
pip install -r requirements.txt
```

4. Copy `.env.example` to `.env` or export the same environment variables in your host.
5. Set `DISCORD_TOKEN`.
6. Set `GROQ_API_KEY` if you want AI.
7. Run:

```bash
python manifest_v8.py
```

## Discord Developer Portal

Enable the privileged intents required by the bot:
- Message Content Intent
- Server Members Intent

The bot also needs the Discord permissions appropriate for the features you enable, including Connect/Speak for music, Manage Channels for tickets, and the relevant moderation/role permissions.

## Persistent AI memory hierarchy

Manifest now has separate scopes:

- **Maker memory** — global across all servers (`/maker_memory`, `/maker_memories`)
- **Maker rules** — global persistent instructions (`/maker_rule_add`, `/maker_rules`)
- **Server memory** — only for the current server (`/server_remember`, `/server_memories`)
- **Personal memory** — per member, per server (`/remember`, `/memories`)
- **Memory about others** — Maker/server managers can use `/remember_user`
- **Persistent AI conversation history** — recent turns are stored in SQLite per server/member
- **Command audit log** — slash commands are logged, but one-off commands are not automatically converted into permanent rules

To explicitly turn a Maker message into a permanent rule, send a message such as:

`Manifest remember: always use concise responses in my servers.`

The bot intentionally does **not** treat every Maker command as a permanent instruction; that would make one-time actions and accidental commands persist forever.

Maker rules are highest-priority bot configuration within legitimate Discord capabilities. They cannot bypass Discord permissions/role hierarchy, Discord platform security, or higher-priority safety requirements.

## Music

Commands:

`/play`, `/pause`, `/resume`, `/skip`, `/stop`, `/queue`, `/nowplaying`, `/shuffle`, `/remove`, `/clearqueue`, `/volume`, `/leave`

`/play` accepts a supported URL or search phrase through `yt-dlp`. FFmpeg handles the voice stream. Use sources you are authorized to stream and follow the source service's rules.

## Server / community features

- Tickets with staff claiming and automatic AI assistance after a short unclaimed period
- Moderation: warn, warnings, timeout, kick, ban, purge, lock, unlock, slowmode
- Role management and reaction roles
- Restricted-word AutoMod
- Dead-chat revival
- Audit-log anti-nuke monitoring
- Tags
- Polls
- AFK
- Reminders
- Invite leaderboard
- XP/levels and leaderboard
- Economy: balance, beg, daily, deposit, withdraw, transfer, work
- Utility: ping, avatar, dice roll, coin flip, help

## Native equivalents vs other bots

Manifest implements its own equivalents for common Carl-bot/Dyno/MEE6-style functions such as moderation, tags, reaction roles, tickets, logging, XP, and AutoMod. It cannot directly control another bot's private database or commands, so features that belong specifically to Mudae/Dank Memer remain separate unless their own public APIs/integration mechanisms are available.

## Security / permissions

Manifest does not pretend to be the Discord server owner and cannot bypass Discord's permission model. All administrative actions are still checked by Discord permissions and role hierarchy.
